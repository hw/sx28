/* mult8x8.cpp */

/* copyright.txt

ESX28 is copyright 2005-2006 Bob Senser

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the 
"Software"), to deal in the Software without restrictions, including
without limitation the rights to use, copy, modify, publish,
sublicense, and/or sell copies of the Software, and to permit persons
to whom the Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be 
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL BOB SENSER BE LIABLE FOR ANY CLAIM, DAMAGES, OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE
ARISING FROM, OUT OF OR IN CONNECTION WITH THIS THE SOFTWARE OR THE
USE OR OTHER DEALINGS OF THE SOFTWARE.

*/ 

// #define TRACE

#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#include "sxcore.h"

#include "pdl_rdr.h"

static unsigned char global_ra;
static unsigned char global_rb;
static unsigned char global_rc;

unsigned char ra_read_main(unsigned char tris, unsigned char value,
		void *tramp) {

	value = global_ra & 0x0f;
#ifdef TRACE
	printf("ra_read_main called, (%x, %x)\n", tris, value);
#endif
	return value;
}

unsigned char rb_read_main(unsigned char tris, unsigned char value,
		void *tramp) {
	
	value = global_rb;
#ifdef TRACE
	printf("rb_read_main called, (%x, %x)\n", tris, value);
#endif

	return value;
}

unsigned char rc_read_main(unsigned char tris, unsigned char value,
		void *tramp) {

	value = global_rc;
#ifdef TRACE
	printf("rc_read_main called, (%x, %x)\n", tris, value);
#endif
	
	return value;
}


void ra_write_main(unsigned char tris, unsigned char value,
		void *tramp) {

	global_ra = value & 0x0f;

#ifdef TRACE
	printf("ra_write_main called, (%x, %x)\n", tris, global_ra);
#endif

}

void rb_write_main(unsigned char tris, unsigned char value,
		void *tramp) {

	global_rb = value;

#ifdef TRACE
	printf("rb_write_main called, (%x, %x)\n", tris, global_rb);
#endif

}

void rc_write_main(unsigned char tris, unsigned char value,
		void *tramp) {

	global_rc = value;

#ifdef TRACE
	printf("rc_write_main called, (%x, %x)\n", tris, global_rc);
#endif

}


int main(int argc, char *argv[]) {

	bool in_run_mode;
	char input_name[256];
	char run_mode;
	unsigned long int total_cycles;
	int return_value;

	int i;
	int j;
	int product;
	int test_product;

	int tests;
	int errors;
	clock_t start;
	clock_t finish;
	double duration;

	struct core_cxt main_cxt;

	if (argc < 2) {
		printf("error: input file name not supplied!\n");
		exit(0);
	}

	run_mode = 'r';

	if (argc == 2) {
		strcpy(input_name, argv[1]);
	} else if (argc == 3) {
		strcpy(input_name, argv[2]);
		if (argv[1][0] == '-') {
			run_mode = argv[1][1];
		} else {
			printf("error: wrong input (argc/argv) format! (1)\n");
			exit(0);
		}
	} else {
		printf("error: wrong input (argc/argv) format! (2)\n");
		exit(0);
	}

	if (run_mode != 'r' && run_mode != 'd') {
		printf("error: unknown input (argc/argv) command!\n");
		exit(0);
	}
		

	if ((return_value = lstrdr(input_name, pgm_mem_size , 
			main_cxt.pgm_mem)) < 0) {
		printf("Error: input file did not open!\n");
		exit(0);
	}

	main_cxt.carryx_mode = false;
	if ((return_value & RDR_CARRYX_PRESENT) != 0) {
		main_cxt.carryx_mode = true;
		printf("Warning: CARRYX Mode is active!\n");
	}

	// display/dump SX program and exit
	if (run_mode == 'd') {
		show_pgm(&main_cxt, 'd');
		exit(0);
	}

	if ((return_value & RDR_SX28_DEFINED) == 0) {
		printf("Error: Only SX28 is currently supported!\n");
		exit(0);
	}

	// setup the I/O callback functions
	main_cxt.ra_read = ra_read_main;
	main_cxt.ra_write = ra_write_main;
	main_cxt.rb_read = rb_read_main;
	main_cxt.rb_write = rb_write_main;
	main_cxt.rc_read = rc_read_main;
	main_cxt.rc_write = rc_write_main;
	main_cxt.rtcc_read = NULL;
	main_cxt.tramp = NULL;
	main_cxt.serial_hook = NULL;

	total_cycles = 0;
	main_cxt.break_addr = -1;

	tests = 0;
	errors  = 0;

	sx_init(&main_cxt);

	printf("mult8x8 and esx-28 v%d emulator running\n",
					main_cxt.major_version);
	
	start = clock();

	for (i = 0; i < 256; i++) {
		for (j = 0; j < 256; j++) {

			global_rb = i;
			global_rc = j;

			sx_init(&main_cxt);

			in_run_mode = true;

			while (in_run_mode) {

				return_value = sx_core(RUN_MODE_SINGLE, &main_cxt);
				if (return_value < 1) {
					printf("sx28_core return: %d\n", return_value);
					switch (return_value) {
						case (RUN_FAIL_UNKNOWN_INSTRUCTION):
						printf("error: unknown instruction\n");
						break;
						case (RUN_FAIL_INVALID_OPTION):
						printf("error: invalid instruction option\n");
						break;
						case (RUN_FAIL_STACK_ERROR):
							if (main_cxt.core_exit_status & CORE_EXIT_STACK_OVERFLOW) {
								printf("error: stack overflow\n");
							} else if (main_cxt.core_exit_status & CORE_EXIT_STACK_UNDERFLOW) {
								printf("error: stack underflow\n");
							} else {
								printf("error: stack error\n");
							}
							break;
						case (RUN_FAIL_ADDRESS_ERROR):
							if (main_cxt.core_exit_status & CORE_EXIT_BAD_PGM_ADDRESS) {
								printf("error: bad page address\n");
							} else if (main_cxt.core_exit_status & CORE_EXIT_BAD_FILE_ADDRESS) {
								printf("error: bad data/file address\n");
							} else {
								printf("error: address error\n");
							}
							break;

						}
					goto direct_exit;
				}
				total_cycles += return_value;
				// output status notes
				if (main_cxt.core_exit_status & CORE_EXIT_SLEEP) {
#ifdef TRACE
					printf("sleep instruction executed!\n");
#endif
					in_run_mode = false;
				}

			} // while

			product = i * j;
			test_product = (global_rc * 256) + global_rb;
			tests++;
			if (product == test_product) {
#ifdef TRACE
				printf("%x * %x is %x, OK\n", i, j, test_product);
#endif
			} else {
				printf("barf! %x * %x is not %x!\n", i, j, test_product);
				errors++;
			}

		} // for
	} // for
direct_exit:

	finish = clock();
	duration = (double)(finish - start) / CLOCKS_PER_SEC;
	printf( "%2.4f seconds\n", duration );

	printf("Total cpu cycles: %ld\n", total_cycles);
	printf("CPU cycles / second: %2.1f\n", total_cycles / duration);
	printf("Tests run:    %d\n", tests);
	printf("Errors found: %d\n", errors);

	return 0;

}