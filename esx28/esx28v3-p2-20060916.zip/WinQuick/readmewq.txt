esx28v3
05/01/2006

Modified 09/12/2006 for V3 patch 1.

This directory contains a very simple Windows-based demo of esx28v3.

There are three demo/diagnostic SX-28 programs to run:

diagpre.lst:  This is the preliminary SX-28 diagnostic program which just tests
              a few of the common instructions.  If the program ends with a
              zero in the W register, then no errors were found.  This is run via:
              
              c:> esx28v3 diagpre.lst

              and then enter the 'r' command to run the program, use the 'x'
              command to exit the program.

serial_ttt.lst: 
serial_ttt_50Mz.lst: 
              This is an SX-28 Basic progam (serial_ttt.sxb) that plays a
              reasonable game of tic-tac-toe, I/O via serin/serout.  This is
              run via:

              c:> esx28v3 -sx serial_ttt.lst           <-- patch level 0
              c:> esx28v3 -sx serial_ttt_50Mz.lst      <-- patch level 1

              and then enter follow the instructions.  The cells of the tic-tac-toe
              board are numbered 1 through 9.

mult8x8.lst:  This is the Ubicom/Parallax SxArith.src 8 bit multiply routine run for
              each possible combination of multiplies (2^8 * 2^8 times).  This is also
              a benchmark of sorts as it notes the time to run and the number of
              emulated cycles.  This is run via:

              c:> mult8x8 mult8x8.lst

end of readme.txt
