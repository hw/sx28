readme_dwutil.txt
09/03/2007

Note: The dwutil reformatter is being abandoned as it is no longer needed given
the recent improvements in CC1B and the CC1B2SX converter.  This directory
contains the full source code and an executable in the event someone still
needs access to this utility.
