readme.txt for C4SX, version 0.3, released 09/04/2007

See the C4SX_Environment.pdf for a Quick Start and documentation on C4SX.  This
referenced document contains a description of what has changed with C4SX, 
version 0.3.

CC1B must be reinstalled, with CC1B version 0.7A or better.  The example programs in
this version of C4SX depend on the CC1B 0.7A enhancements.

There is no need to reinstall Notepad++.

This C4SX version was tested with CC1B version 0.7A beta.

