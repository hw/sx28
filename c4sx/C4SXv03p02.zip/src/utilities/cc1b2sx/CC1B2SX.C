/************************************************************************/
/*									*/
/*			      C C 1 B 2 S X . C				*/
/*									*/
/************************************************************************/
/*									*/
/*		     Copyright (C) 2007-2008  SimuLogics		*/
/*			All rights reserved worldwide			*/
/*									*/
/* This software is provided "as-is", without any express or implied	*/
/* warranty.								*/
/* In no event will the authors be held liable for any damages arising	*/
/* from the use of this software.					*/
/*									*/
/* Permission is granted to anyone to use this software for any		*/
/* purpose, including commercial applications, and to alter it and	*/
/* redistribute it freely, subject to the following restrictions:	*/
/*									*/
/* 1. The origin of this software must not be misrepresented; you must	*/
/*    not claim that you wrote the original software. If you use this	*/
/*    software in a product, an acknowledgment in the product		*/
/*    documentation would be appreciated but is not required.		*/
/*									*/
/* 2. Altered source versions must be plainly marked as such, and must	*/
/*    not be misrepresented as being the original software.		*/
/*									*/
/* 3. This notice may not be removed or altered from any source		*/
/*    distribution.							*/
/*									*/
/************************************************************************/

/*
Release history:


2007-Dec-28, bkr	0.00.07
	. files specified on command line now appended to .src file (lines prefixed with "; ")
	. removed 'pragma_line()' routine.
	. removed corresponding -h and -t command line argument handling.
	. made open source license official

2007-Aug-21, rws	0.00.06
	. added code to comment out STATUS and RTCC assember EQUs, if present 

2007-Jul-30, rws	0.00.05
	. disabled the reading of the HDR and TRL files
	. these can be reenabled by adding '#define ENABLE_HDRTRL'
	. changed to version '.05'

2007-Jul-25, bkr	0.00.04
	. added / *<?asm ... ?>* / minimalist handling
	. parameterized pragma name (for future enhancements)
	. removed #pragma processing as CC1B chokes on unknown pragma names
	. changed 'fgets()' buffer size argument to be defensive.

2007-Jul-24, bkr	0.00.03
	. added #pragma SX <SX-Key line> to capabilities
	. added time and date of translation for reference
	. invalid command line arguments now display error message

2007-Apr-27, bkr	0.00.02
	. added insert header file option;
	  -h for explicit name, else default of 'cc1bsx.hdr'
	. added insert trailer file option;
	  -t for explicit name, else default of 'cc1bsx.trl'
	. 'RESET main' substitution removed from the change list;
	  use header or trailer file as appropriate

2007-Apr-21	0.00.01	initial development alpha release


	converts CC1B compiler assembler code to SX-Key acceptable code


uses output from compiler:

	CC1B version 0.7A beta or later (Copyright (c) B Knudsen Data)



To create an .asm file from original .c source file:

	cc1b  -a  <filename.c>


	use:		cc1b2sx  [options] < input_file  > output_file  [ <file>... ]

	where:
		options:

		-s		shift ';'-prefixed lines to the left margin

		< input_file	redirection of input file

		> output_file	redirection of output file

		<file>		file(s) to be appended to end of .src file;
				(each line prefixed with "; ")

	return:	0	no errors (success?)
		1	invalid option,
			or no argument specified to option


todo:
	<nothing>

Notes:
	- header and trailer files are optional

Warnings:
	- very picky and sensitive about compiler output format
	- no error message sent to stdout for command line option error
	  so output file can have 0 bytes on error, but stderror is used for errors
	- compiler does not know about assembler code so may use registers asm code uses!
 */

#define	PROG_VERSION	"0.00.07"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#if	defined(_WIN32) || defined(WIN32)
							/*----------------------*/
							/*        Windows	*/
							/*----------------------*/

#define	EACH_APPEND_FILE	a = 1 ; a < argc ; ++a		/*  (Windows includes program name as part of argv[])  */

#else
							/*----------------------*/
							/*	   U*IX		*/
							/*----------------------*/

#define	EACH_APPEND_FILE	a = 0 ; (a+1) < argc ; ++a	/*  (U*IX does not include program name as part of argv[])  */

#endif	/*  _WH_CONSOLE_  */



/*  additional text substitution or reserved words
    (from CC5B Compiler Manual Appendix)
W
INDF	TMR0	PCL	STATUS	FSR	PORTA	PORTB	PORTC
INDF0	RTCC	PC  // alternative names of above //
OPTION	TRISA	TRISB	TRISC
Carry	DC	Zero_	PD	TO	PA1	PA2
FSR_5	FSR_6
*/

#define	LINE_SIZE	2048

static	int	shift		= 0 ;		/*  shift listing comments to left margin  */
static	char	lineIn [ LINE_SIZE ] ;
static	char	lineOut[ LINE_SIZE ] ;


		/*----------------------------------------------*/
		/*	      text substitution table		*/
		/*----------------------------------------------*/
static struct
	{
	char *		matchStr ;
	char *		newStr ;
	}    subTable[] =

	{
		/*  SX register references  */

	  { "RA "			, ";-- RA "		}
	, { "RB "			, ";-- RB "		}
	, { "RC "			, ";-- RC "		}
	, { "RD "			, ";-- RD "		}
	, { "RE "			, ";-- RE "		}
	, { "INDF "			, ";-- INDF "		}
	, { "FSR "			, ";-- FSR "		}
	, { "PC "			, ";-- PC "		}
	, { "PCL"			, ";-- PCL "		}
	, { "RTCC "			, ";-- RTCC "		}
	, { "STATUS "			, ";-- STATUS "		}
	, { "        ORG $07FF"		, "        ;--- ORG $07FF"		}
	, { "        ORG $01FF"		, "        ;--- ORG $01FF"		}
/*	, { "        JMP main"		, "        RESET main     ;-- JMP main" }
 */
	, { "        JMP main"		, "        ;-- JMP main"}
	, { NULL			, NULL			}
	} ;


		/*----------------------------------------------*/
		/*		    substitute			*/
		/*----------------------------------------------*/

	static char * substitute( char in[], char out[] )
		{
		char *		p ;
		char *		p1 ;
		int		a ;
		int		b ;

		out[0] = '\0' ;
		p1 = p = in ;

		/* retain leading whitespace for now
		 *
		 * for ( p1 = p = in ; ((*p1 == ' ') || (*p1 == '\t')) ; ++p1 )
		 *	{
		 *	}
		 */
		p1 = p ;
		for ( a = 0 ; (subTable[a].matchStr) ; ++a )
			{
			b = strlen( subTable[a].matchStr ) ;
			if ( strncmp(p1,subTable[a].matchStr,b) == 0 )
				{
				strcat( out, subTable[a].newStr ) ;
				p1 = p + b ;
				break ;
				}
			}
		strcat( out, p1 ) ;
		return ( out ) ;
		}	/*  end of 'substitute'  */


		/*----------------------------------------------*/
		/*		      sxkey_code		*/
		/*----------------------------------------------*/

	int sxkey_code( char in[], char out[], char * leadin, char * leadout, FILE * inFp, FILE * outFp )
		{
		char *		p ;
		char *		p1 ;
		int		result ;

		/* Q & D search for 'leadin' and 'leadout' done,
		 * no trailing whitespace detection done;
		 * no end of file without 'leadout' detection done
		 */
		result = 0 ;
		/*  eat leading whitespace  */
		for ( p = in ; ((*p == ' ') || (*p == '\t')) ; ++p ) {}
		if ( *p == ';' )
			{
			for ( ++p ; ((*p == ' ') || (*p == '\t')) ; ++p ) {}
			if ( strncmp(p,leadin,strlen(leadin)) == 0 )
				{
				/*  start with next line  */
				/*  copy in to out until 'leadout' seen  */

				while ( (fgets(in,sizeof(lineIn),inFp)) )
					{
					for ( p = in ; ((*p == ' ') || (*p == '\t')) ; ++p ) {}
					if ( *p == ';' )
						{
						for ( p1 = ++p ; ((*p1 == ' ') || (*p1 == '\t')) ; ++p1 ) {}
						if ( strncmp(p1,leadout,strlen(leadout)) == 0 )
							{
							break ;
							}
						fprintf( outFp, "%s", p ) ;
						}
					}
				result = 1 ;
				}
			}
		return ( result ) ;
		}	/*  end of 'sxkey_code' */


		/*----------------------------------------------*/
		/*		      do_shift			*/
		/*----------------------------------------------*/

	static char * do_shift( char * p )
		{
		char *		p1 ;

		/*  determine if ';' is first non-whitespace character in line;
		 *  return original line if not,
		 *  return position of ';' if true.
		 */
		for ( p1 = p ; ((*p1 == ' ') || (*p1 == '\t')) ; ++p1 )
			{
			}
		return ( (*p1 == ';') ? p1 : p ) ;
		}	/*  end of 'do_shift'  */


		/*----------------------------------------------*/
		/*		      insertFile		*/
		/*----------------------------------------------*/

	static int insertFile( char * fileName)
		{
		int		a ;
		FILE *		fp ;

		/*  append specified file to output;
		 *  prefix each input line with a "; " comment designator
		 */
		a = 0 ;
		fp = fopen( fileName, "rt" ) ;
		if ( fp )
			{
			printf( "\n\n\n; file: %s \n\n", fileName ) ;
			while ( fgets(lineIn,sizeof(lineIn),fp) )
				{
				printf( "; %s", lineIn ) ;
				++a ;
				}
			fclose( fp ) ;
			}
		return ( a ) ;
		}	/*  end of 'insertFile'  */


	/*==============================================================*/
	/*				main				*/
	/*==============================================================*/

int main( int argc, char * argv[] )
	{
	int		a ;
	char *		p ;
	time_t		ltime ;

	shift = 0 ;
	for ( a = 1 ; a < argc ; ++a )
		{
		if ( strcmp(argv[a],"-s") == 0 )
			{
			shift = 1 ;
			}
		else
			{
			/*  append files are now valid command line arguments...
			 *  fprintf( stderr, "error - invalid option: %s \n", argv[a] ) ;
			 *  return ( 1 ) ;
			 */
			}
		}	

	printf( ";-- cc1b2sx [rev %s] \n", PROG_VERSION ) ;
	time( &ltime ) ;
	printf( ";-- %s \n", ctime(&ltime) ) ;
	while ( fgets(lineIn,(sizeof(lineIn)-1),stdin) )
		{
		if ( ! sxkey_code(lineIn,lineOut,"/*<?asm", "?>*/",stdin,stdout) )
			{
			substitute( lineIn, lineOut ) ;
			p = (shift) ? do_shift(lineOut) : lineOut ;
			printf( "%s", p ) ;
			}
		}
	/*  possible CC1B files appended to .src file:
	 *
	 *	.fcs	procedure reference summary
	 *	.occ	memory usage summary
	 *	.var	variable summary
	 */
	for ( EACH_APPEND_FILE )
		{
		insertFile( argv[a] ) ;
		}
	return ( 0 ) ;
	}	/*  end of 'main'  */
