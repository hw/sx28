2008-02-03

C4SX ReleaseV03 Patch 02  (Note:  Patch 01 was not widely released)


Purpose: Better Notepad++ Integration


This patch provides improved C4SX.bat and cc1b2sx.exe modules that make it very 
easy to execute the CC1B compiler from within the notepad++ "IDE". No changes in basic
C4SX or CC1B functionality are involved.

Installation:

To install this patch, unzip the C4SXv03p02.zip file into your c:\C4SX
directory (or into which ever directory you installed C4SX).

This patch will overlay the C4SX.bat, cc1b2sx.exe and src\utilities\cc1b2sx\CC1B2SX.C
files in your CDSX directory.  It will also add this readmeP02.txt file to
your C4SX directory.

Notepad++ Configuration:

After this patch has been installed, notepad++ needs the following line inserted 
into the F5 ("Run | Run...") option:

C:\C4SX\C4SX.bat /WAIT "$(NAME_PART)" - C:\C4SX

and a name provided, such as "C4SX_Compile".  This will add an entry to the items 
that can be started from "Run".  To delete or change what you have added, use 
"Settings | Shortcut Mapper...".  Note that if you have C4SX installed in a 
location other than "C:\C4SX", you will need to change the line inserted into 
notepad++'s Run option.

This version of C4SX.bat has the CC1B compiler create many output files including 
the ".cpr", ".fcs", ".hex", ".occ", ".var", and of course, ".src" files.  If you 
want to limit these, please see the comments in C4SX.bat.


