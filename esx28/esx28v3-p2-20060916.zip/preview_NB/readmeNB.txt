May 1, 2006

This directory contains a work-in-progress port of ESX28 to the NetBurner MOD5213.

The embed.cpp program drives sxcore.cpp and contains the diagpre, diagfull and
mult8x8 SX28 test programs.

This port is incomplete in the sense that some of the output from embed.cpp does
not line up as it does under Windows and/or LINUX.

The mult8x8 SX28 program runs 30 to 100 times slower than it does when run on
a small PC.

Executable is zipped in esx28_app.zip.