/* main.cpp */

/* enhanced 11/2005 to 02/2006 for serial support */

/* mugged 09/2006 to change seral support */

/* copyright.txt

ESX28 is copyright 2005-2006 Bob Senser

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the 
"Software"), to deal in the Software without restrictions, including
without limitation the rights to use, copy, modify, publish,
sublicense, and/or sell copies of the Software, and to permit persons
to whom the Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be 
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL BOB SENSER BE LIABLE FOR ANY CLAIM, DAMAGES, OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE
ARISING FROM, OUT OF OR IN CONNECTION WITH THIS THE SOFTWARE OR THE
USE OR OTHER DEALINGS OF THE SOFTWARE.

*/ 

/*
  Maintenance History:
  Date     Comments
  10/19/05 major upgrade to esx28v2, all SX instructions working, RTCC
           pin and RTCC-based interrupt supported.
  02/14/06 major upgrade to esx28v<?>, serial support on pins 2 and
           3 added (Windows only)
  04/29/06 Added somewhat more help info on command option errors in
		   the form of the help function.
-- Fixes post V3.0
Date 09/03/2006:
   Added serial_io cycles_used and debug logging.
   Added output of cycles used to output display.
*/

#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>

#include "sxcore.h"

#include "pdl_rdr.h"

//
// for serial support!
//
#ifdef WIN32

#include <windows.h>
#include <process.h>
#include <conio.h>

HANDLE threadHandle = NULL;
unsigned thId = 0;
LPVOID thArg = NULL;
CRITICAL_SECTION protectBuffer;
bool threadCharPresent = false;
unsigned char threadChar = 0;

#endif

#ifdef WIN32
	// timing constants determined by baud rate....
	// const int wait1 = 66; 
	const double kbs = 19.2; 
	const int mhz = 50;
	const int wait1 = 1375; // 50:1375; // 4:110; // 4,1:66; // 825;    // 66 * 50 / 4
	const int wait2 = wait1 * 2;
	const int total_bits = 9;
#endif

#define QUIET

// FIX 06/03/2006
// #define SERIAL_DEBUG

// next line from #include "pdlgen\pdl_code.h"
int getR_PC();
int getR_WREG();

static int global_RA = 0;
static bool in_run_mode;
static unsigned long int total_cycles;


unsigned char ra_read_main(unsigned char tris, unsigned char value,
				void *tramp) {

	value = global_RA;
#ifndef QUIET
	printf("ra_read_main called, (%x, %x, %x)\n", tris, value, tramp);
#endif
	return value;
}

unsigned char rb_read_main(unsigned char tris, unsigned char value,
				void *tramp) {

	
	value = 0x05;
#ifndef QUIET
	printf("rb_read_main called, (%x, %x)\n", tris, value);
#endif
	return value;
}

unsigned char rc_read_main(unsigned char tris, unsigned char value,
				void *tramp) {

	value = 0x06;
#ifndef QUIET
	printf("rc_read_main called, (%x, %x)\n", tris, value);
#endif	
	return value;
}


void ra_write_main(unsigned char tris, unsigned char value,
				void *tramp) {

	global_RA = value;
#ifndef QUIET
	printf("ra_write_main called, (%x, %x, %x)\n", tris, value, tramp);
#endif
}

void rb_write_main(unsigned char tris, unsigned char value,
				void *tramp) {

#ifndef QUIET
	printf("rb_write_main called, (%x, %x)\n", tris, value);
#endif
}

void rc_write_main(unsigned char tris, unsigned char value,
				void *tramp) {
#ifndef QUIET
	printf("rc_write_main called, (%x, %x)\n", tris, value);
#endif
}

bool rtcc_update_main(bool current_value, int call_mode, void *tramp) {

	// rtcc field
	bool new_value;


	if (call_mode == UPDATE_RTCC_INSTRUCTION) {
		new_value = !current_value; // toggle
	} else {
		new_value = current_value;	// no change
	}

	// commented out due to high volume of output....
	// printf("rtcc_update_main called, (%x, %x, %x)\n",
	//	call_mode, current_value, new_value);

	return new_value;

}

//
// serial support thread for console input
//

#ifdef WIN32
static unsigned int WINAPI thCode (LPVOID thArg) {

	unsigned char localChar;
	
	// we will be here for a while.... <smile>
	while (1) {

		if (threadCharPresent == false) {
			// printf(">");
			localChar = _getch();	// get char with no echo
			EnterCriticalSection(&protectBuffer);
			if (localChar == 0x03) {	// control-C
				in_run_mode = false;	// break processor!
				printf("\n*** control-C ***\n");
			} else {
				threadCharPresent = true;
				threadChar = localChar;
			}
			LeaveCriticalSection(&protectBuffer);
			if (in_run_mode == false) {
				break;
			}
		} else {
			Sleep(250);  // let Sally ride!
		}
	}	

	return 0;

}
#endif

void serial_io(void * tramp_ptr, int cycles_used) {

	// provide serial support, required SX settings:
    // clock 4MHz, 19200 kbs (timer value is 66, 22 with 57600)
	// or clock 50 MHz, 19200 bits/second (timer value is 66 * 50 / 4)
	// input on bit RA.2
	// output on bit RA.3

	// think of "bit blasting" ....

#ifdef XXXX
	// timing constants determined by baud rate....
	// const int wait1 = 66; 
	const float kbs = 19.2; 
	const int mhz = 50;
	const int wait1 = 1375; // 50:1375; // 4:110; // 4,1:66; // 825;    // 66 * 50 / 4
	const int wait2 = wait1 * 2;
	const int total_bits = 9;
#endif

#ifdef WIN32
	// output control fields
	bool out_bit;
	static bool previous_bit; 
	static bool first_time = 1;
	static int bit_count = 0;
	static int call_count = 0;
	static unsigned char ch;

	// input control fields
	bool in_bit;
	static bool in_ch_present = false;
	static int in_bit_count = 0;
	static int in_call_count = 0;
	static unsigned char in_ch = 0xA1;
	static int trick_count = -999;

	// FIX 09/03/2006
#ifdef SERIAL_DEBUG
	// debug fields
	static FILE *log;
	static unsigned int serial_debug_count = 0;
#endif

	// cycles_used = 1;  // DEBUG

	//
	// kick off reader thread
	//
	if (thId == 0) {

		global_RA |= 0x04;  // Research why this is needed!!!

		InitializeCriticalSection(&protectBuffer);

		threadHandle = (HANDLE) _beginthreadex(
			NULL,
			0,
			thCode,
			thArg,
			0,
			&thId);

		if (thId == 0) {
			printf("no thread\n");
			exit(0);
		}

// FIX 09/03/2006
#ifdef SERIAL_DEBUG
		log = fopen("slog.txt", "w");
		if (log == NULL) {
			printf("serial debug fopen failed\n");
			exit(0);
		}
		fprintf(log,"wait1=%d, wait2=%d\n", wait1, wait2);
		fprintf(log,"         port         cyc output.. input... total\n");
		fprintf(log,"cnt..... ra ra:3 ra:0 les call bit call bit cycles..\n");
		fflush(log);
#endif
	}

	//
	// process serial output from ESX
	//
#if 1
	out_bit = ((global_RA & 0x08) > 0);  // RA.3 bit

	if (first_time) {
		first_time = 0;
		previous_bit = out_bit;
		// printf("DEBUG first time bit: %x\n", out_bit);
	}

	// process serial output from ESX
	// edge-triggered start bit?
	if (bit_count == 0 && out_bit == 0 && out_bit != previous_bit) {
		// printf("DEBUG out; start bit!\n");
		call_count = wait1 + wait2;
		bit_count = 1;
		ch = 0;		
	} else {
	// already scanning?
		if (call_count > 0 && bit_count > 0) {
			// printf("DEBUG counting for bits!\n");
			// call_count--;
			call_count -= cycles_used;
			if (call_count <= 0) {
				// printf("DEBUG out; got bit: %x (bit_count: %x)!\n", out_bit, bit_count);
				ch = ch + (out_bit << (bit_count - 1));
				call_count = wait2;
				bit_count++;
			}
			if (bit_count >= total_bits) {
				call_count = 0;
				bit_count = 0;
				// printf("DEBUG out; ch: %x\n", ch);
				if (isprint(ch) || ch < ' ') {
					printf("%c", ch);
				} else {
					printf(" 0x%x ", ch);
				}
			}
		}
	} 

	previous_bit = out_bit;

#endif

	//
	// process serial input to ESX
	//
#if 1

#if 0
	// DEBUG trick for testing
	if (ch == '$' && call_count == 0 && trick_count < 0 ) {
		if (trick_count == -999) {
			trick_count =  -500; 
			global_RA |= 0x04;  // DEBUG
			// printf("DEBUG8, start input chars, global_RA: %x!\n", global_RA);
		} else {	// delay while SERIN gets going.....
			trick_count++;
			// printf("DEBUG9, delay, global_RA: %x!\n", global_RA);

		}
	}
	if (trick_count >= 0 && trick_count < 3 && in_ch_present == false) {
		in_ch_present = true;
		switch (trick_count) {
			case 0: in_ch = '1'; break;
			case 1: in_ch = '2'; break;
			case 2: in_ch = '3'; break;
		}
		trick_count++;
	}
#else

	EnterCriticalSection(&protectBuffer);
	if (threadCharPresent == true) {
		in_ch = threadChar;
		in_ch_present = true;
		threadCharPresent = false;
	}
	LeaveCriticalSection(&protectBuffer);
#endif	

	if (in_ch_present) {
		if (in_bit_count == 0) {
			in_bit_count = total_bits + 2;  // 2 stop bits
			in_call_count = 0;
			// printf("DEBUG0 in_ch= %x, in_bit_count= %d\n", in_ch, in_bit_count);
		}
		if (in_call_count <= 0) {
			if (in_bit_count == (total_bits) + 2) {
				in_call_count = wait2;
				// send low start bit
				global_RA &= ~(0x04);
				// printf("DEBUG1 %x %d\n", global_RA, in_bit_count);
			} else if (in_bit_count <= 2) {
				in_call_count = wait2;
				// send high stop bit
				global_RA |= 0x04;
				// printf("DEBUG2 %x %d\n", global_RA, in_bit_count);
			} else {
				in_call_count = wait2;
				// send data bit
				in_bit =  ( ( (in_ch >> (7 - (in_bit_count - 3)) ) & 0x01) > 0);
				if (in_bit) {
					global_RA |= 0x04;
				} else {
					global_RA &= ~(0x04);
				}
				// printf("DEBUG3 %x %d %x\n", global_RA, in_bit_count, in_bit);
			}
			in_bit_count--;
			if (in_bit_count == 0) {
				in_ch_present = false;
				in_call_count = 0;
			}
		}
		if (in_ch_present) {
			// in_call_count--;
			in_call_count -= cycles_used;
		}
	}

	// FIX 09/03/2006
#ifdef SERIAL_DEBUG
	serial_debug_count++;
	if (log != NULL) {
		fprintf(log,"%8d %02x   %1x    %1x  %3x %4d %3d %4d %3d %8d\n",  
			serial_debug_count, global_RA,
			(out_bit == 0) ? 0 : 1,
			((global_RA & 0x04) == 0) ? 0 : 1,
			cycles_used,
			call_count,
			bit_count,
			in_call_count,
			in_bit_count,
			total_cycles);
		fflush(log);
	}
#endif	

#endif

// WIN32...
#endif

}

void help(char * program) {
	printf(
	"Help information:\n\n"
	"    Usage syntax: %s [<-options>] <input_file>\n"
	"    Example: %s -rx diagpre.lst\n"
	"\n"
	"    Options:\n"
    "    -d: Dump input SX program in hex and immediately exit\n"
    "    -c: Dump input SX program in C format and immediately exit\n"
	"\n"
	"    -r: Run SX program (default behavior if no option used)\n"
	"    -rx: Run SX program immediately (no prompt)\n"
#ifdef WIN32
	"\n"
	"    -s: Run SX program with serial support\n"
	"    -sx: Run SX program immediately with serial support\n"
#endif
	, program, program);

	return;

}

int main(int argc, char *argv[]) {

	bool do_exit;
	bool serial_active;
	bool auto_start;
	// unsigned int *ptr;
	unsigned short *ptr;
	char data[32];
	char input_name[256];
	char run_mode;
	// unsigned long int total_cycles;
	int return_value;

	struct core_cxt main_cxt;

	/*
	currently three modes of operation:
	1) normal: which runs sx program, default or -r
	2) serial: which runs sx program plus serial, -s
				(uses RA.2 input, RA.3 output)
    3) display: which only dumps the loaded SX program, -d or -c

	adding an 'x' to either 'r' or 's' causes immediate execution

	*/

	if (argc < 2) {
		printf("error: input file name not supplied!\n");
		help(argv[0]);
		exit(0);
	}

	// defaults
	run_mode = 'r';
	serial_active = false;
	auto_start = false;

	if (argc == 2) {
		strcpy(input_name, argv[1]);
	} else if (argc == 3) {
		strcpy(input_name, argv[2]);
		if (argv[1][0] == '-') {
			if (argv[1][1] == 's') {
				run_mode = 'r';
				serial_active = true;
			} else {
				// whatever...
				run_mode = argv[1][1];
			}
			if (strlen(argv[1]) > 2) {
				if (argv[1][2] == 'x') {
					auto_start = true;
					// printf("autorun!\n");
				}
			}
		} else {
			printf("error: wrong input (argc/argv) format! (1)\n");
			help(argv[0]);
			exit(0);
		}
	} else {
		printf("error: wrong input (argc/argv) format! (2)\n");
		help(argv[0]);
		exit(0);
	}

	// currently serial is Windows-only due to use of thread
	// for console input...
#ifndef WIN32
	if (serial_active) {
		printf("Sorry: Serial support currently supported only with WIN32!\n");
		exit(0);
	}
#endif

	if (run_mode != 'r' && run_mode != 'd' && run_mode != 'c') {
		printf("error: unknown input (argc/argv) command!\n");
		help(argv[0]);
		exit(0);
	}
		
	if ((return_value = lstrdr(input_name, pgm_mem_size , 
			main_cxt.pgm_mem)) < 0) {
		printf("Error: input file did not open!\n");
		help(argv[0]);
		exit(0);
	}

	main_cxt.carryx_mode = false;
	if ((return_value & RDR_CARRYX_PRESENT) != 0) {
		main_cxt.carryx_mode = true;
		printf("Warning: CARRYX Mode is active!\n");
	}

	// display/dump SX program and exit
	if (run_mode == 'd') {
		show_pgm(&main_cxt, 'd');
		exit(0);
	}

	// display/dump SX program as C code and exit
	if (run_mode == 'c') {
		show_pgm(&main_cxt, 'c');
		exit(0);
	}


	if ((return_value & RDR_SX28_DEFINED) == 0) {
		printf("Error: Only SX28 is currently supported!\n");
		exit(0);
	}

	if (!auto_start) {
		printf("esx-28 emulator running ");
	}

	// setup the I/O callback functions
	main_cxt.ra_read = ra_read_main;
	main_cxt.ra_write = ra_write_main;
	main_cxt.rb_read = rb_read_main;
	main_cxt.rb_write = rb_write_main;
	main_cxt.rc_read = rc_read_main;
	main_cxt.rc_write = rc_write_main;
	main_cxt.rtcc_read = rtcc_update_main;
	if (serial_active) {
		main_cxt.serial_hook = serial_io;
	} else {
		main_cxt.serial_hook = NULL;
	}
	main_cxt.tramp = (void *) 0xff;

	sx_init(&main_cxt);

	if (!auto_start) {
		printf("(version: %d, patch: %d, pdl version: %d)\n",
			main_cxt.major_version, main_cxt.patch_level, main_cxt.pdl_cut);
#ifdef WIN32
		if (serial_active == true) {
			printf("\n(serial options: %g KBs, %i MHz, constant: %i)\n\n", kbs, mhz, wait1);
		}
#endif
	}

	if (auto_start) {
		in_run_mode = true;
	} else {
		in_run_mode = false;
	}
	total_cycles = 0;
	main_cxt.break_addr = -1;

	if (!in_run_mode) {
		dump_regs("INIT");
	}

	while (1) {

		if (((int) getR_PC()) == main_cxt.break_addr) {
			in_run_mode = false;
			printf("break point!\n");
			dump_regs("BRK1");
		}

		// need something better here....
		ptr = main_cxt.pgm_mem;   // pgm;
		ptr += getR_PC();

		if (!in_run_mode) {
			printf("INST: %03x OP: %s Cycles: %d\n",   // FIX 09/03/2006
				*ptr, get_opcode_text(*ptr), total_cycles);
		}

		do_exit = false;

		while (!in_run_mode) {
#ifdef WIN32
			if (thId != 0) {
				// remove char reader thread
				_endthreadex(thId);
				thId = 0;
				fflush(stdin);
				Sleep(250);		// sloppy but effective....
			}
#endif

			printf("      enter <cr>, 'H'elp, 'M', 'T', 'B', 'X' or 'R':");

			gets(data);
			if (toupper(data[0]) == 'X' || 
				toupper(data[0]) == 'Q') {
				do_exit = true;
				break;
			}
			if (toupper(data[0]) == 'H') {
				printf(
					" HELP:\n"
					" H: this help command\n"
					" M: dump the file registers (data), example: M\n"
					" T: dump the TRIS and I/O registers, example: T\n"
					" B: set break point, example: B 1f; B - to clear\n"
					"    BR field shows current break point setting\n"
					" X or Q: exit simulator, example: X\n"
					" R: run simulator, example: R\n"
					" <cr>: enter key, single step, example: <cr>\n"
					"\n");
				break;
			}

			if (toupper(data[0]) == 'M') {
				show_mem();
				dump_regs("----");
				continue;
			}

			if (toupper(data[0]) == 'T') {
				dump_ioregs();
				dump_regs("----");
				printf("Cycles: %ld\n", total_cycles);
				continue;
			}

			if (toupper(data[0]) == 'B') {
				if (data[2] == '-') {
					main_cxt.break_addr = -1;
				} else {
					sscanf(&data[2],"%x",&(main_cxt.break_addr));	
				}
				dump_regs("BRK ");
				continue;
			}

			if (toupper(data[0]) == 'R') {
				in_run_mode = true;
				continue;
			}

			break;
		} // while
		
		if (do_exit) break;

		return_value = sx_core(RUN_MODE_SINGLE, &main_cxt);
		if (return_value < 1) {
			printf("sx28_core return: %d\n", return_value);
			switch (return_value) {
				case (RUN_FAIL_UNKNOWN_INSTRUCTION):
				printf("error: unknown instruction\n");
				break;
				case (RUN_FAIL_INVALID_OPTION):
				printf("error: invalid instruction option\n");
				break;
				case (RUN_FAIL_STACK_ERROR):
					if (main_cxt.core_exit_status & CORE_EXIT_STACK_OVERFLOW) {
						printf("error: stack overflow\n");
					} else if (main_cxt.core_exit_status & CORE_EXIT_STACK_UNDERFLOW) {
						printf("error: stack underflow\n");
					} else {
						printf("error: stack error\n");
					}
					break;
				case (RUN_FAIL_ADDRESS_ERROR):
					if (main_cxt.core_exit_status & CORE_EXIT_BAD_PGM_ADDRESS) {
						printf("error: bad page address\n");
					} else if (main_cxt.core_exit_status & CORE_EXIT_BAD_FILE_ADDRESS) {
						printf("error: bad data/file address\n");
					} else {
						printf("error: address error\n");
					}
					break;

			}
			goto direct_exit;
		}
		total_cycles += return_value;

		if (main_cxt.core_exit_status & CORE_EXIT_SLEEP) {
			if (auto_start) {
				printf("\n%s exit with W: %.02x\n",
					input_name, getR_WREG());
				do_exit = true;
				break;
			}
			else {
				printf("sleep instruction executed!\n");
				in_run_mode = false;
			}
		}
		if (!in_run_mode && 
				(main_cxt.core_exit_status & CORE_EXIT_INTERRUPT)) {
			printf("RTCC interrupt!\n");
		}

		if (!in_run_mode) {
			dump_regs("NEXT");
		}

	} // while

direct_exit:
	printf("Total cpu cycles: %ld\n", total_cycles);

	return 0;

}