readme_samples.txt
09/03/2007


Note:

The following same programs are included:

sxlimits.c - this program shows some of the CC1B compiler C limits and how
             to code around them.

sxview.c -   this program shows an interesting pattern on the SX-Key display
             when run under the SX-Key debugger.

sxwatch.c -  this program shows a bubble sort when run from the debugger; it
             includes the use an SX-Key 'break'.

sxstring.c - these programs test the string functions and can display the test
sxstring48.c results on a serial terminal.  can be run without terminal and the
             results seen at a debug breakpoint.

These programs are replacements for the samples given in C4SX version 01.



