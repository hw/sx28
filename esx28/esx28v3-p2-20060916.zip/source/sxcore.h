/* sxcore.h */

/* copyright.txt

ESX28 is copyright 2005-2006 Bob Senser

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the 
"Software"), to deal in the Software without restrictions, including
without limitation the rights to use, copy, modify, publish,
sublicense, and/or sell copies of the Software, and to permit persons
to whom the Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be 
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL BOB SENSER BE LIABLE FOR ANY CLAIM, DAMAGES, OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE
ARISING FROM, OUT OF OR IN CONNECTION WITH THIS THE SOFTWARE OR THE
USE OR OTHER DEALINGS OF THE SOFTWARE.

*/ 

#define RUN_MODE_FULL 1
#define RUN_MODE_SINGLE 2

#define RUN_FAIL_UNKNOWN_INSTRUCTION -1
#define RUN_FAIL_INVALID_OPTION -2
#define RUN_FAIL_STACK_ERROR -3
#define RUN_FAIL_ADDRESS_ERROR -4

#define CORE_EXIT_SLEEP 0x01
#define CORE_EXIT_BREAK 0x02
#define CORE_EXIT_INTERRUPT 0x04
#define CORE_EXIT_STACK_OVERFLOW 0x08
#define CORE_EXIT_STACK_UNDERFLOW 0x10
#define CORE_EXIT_BAD_PGM_ADDRESS 0x20
#define CORE_EXIT_BAD_FILE_ADDRESS 0x40

#define UPDATE_RTCC_INSTRUCTION 1
#define UPDATE_RTCC_INTERRUPT 2

// const int pgm_mem_size = 4 * 1024;
const int pgm_mem_size = 2 * 1024;	// save some memory

struct core_cxt {

	// version info set by sxcore
	int major_version;
	int patch_level;
	int pdl_cut;

	// values passed to/from sxcore
	int core_exit_status;				// set by sxcore
	int break_addr;						// all remaining fields set by caller
	bool carryx_mode;
	// unsigned int pgm_mem[pgm_mem_size];
	unsigned short pgm_mem[pgm_mem_size];	// save some memory
	void *tramp;
	unsigned char (*ra_read) (unsigned char tris, unsigned char value, void * ptr);
	unsigned char (*rb_read) (unsigned char tris, unsigned char value, void * ptr);
	unsigned char (*rc_read) (unsigned char tris, unsigned char value, void * ptr);
	void (*ra_write) (unsigned char tris, unsigned char value, void * ptr);
	void (*rb_write) (unsigned char tris, unsigned char value, void * ptr);
	void (*rc_write) (unsigned char tris, unsigned char value, void * ptr);
	bool (*rtcc_read) (bool last_rtcc_pin_value, int call_mode, void * ptr);
	void (*serial_hook) (void * ptr, int cycles_used);

};


void dump_ioregs();

void dump_regs(char *);

void show_mem();

void show_pgm(struct core_cxt *, char mode);

unsigned char *get_opcode_text(unsigned int);

void sx_init(struct core_cxt *);

int sx_core (int, struct core_cxt *);

// end of sxcore.h
