09/16/2006

esx28v3 top-level readme.txt file

esx version 3, patch level 2, package 0

This file contains any last minute notes for this release plus other information.

If you want to quickly see this emulator execute a few programs, see the
readmewq.txt in the WinQuick directory

1)  Last minute notes:

    Two bugs were found in the interrupt handling and those are fixed in P1.  The
    source code for sxcore.cpp describes these errors.

    The serial I/O handling is also upgraded in this patch.  The emulated SX now
    runs at a "virtual" 50 MHz and the baud rate remains at 19.2 Kb. 

    The documents in the docs subdirectory are not updated for this patch. 

    The preview_VPUART was added to show the emulated SX running interrupts.  See
    the readme_VPUART in the preview_VPUART directory.

    The preview_NB remains at the P0 level.

2)  The release zip file contains these directories and files:

    copyright.txt
    readme.txt
    version.txt

    bin directory (windows binary files)
        esx28lib.lib
        esx28v3.exe
        mult8x8.exe        

    diags directory (diagnostic programs for SX-28)
        a large number of test programs including diagpre.lst, diagfull.lst,
        mult8x8.lst, serial_ttt.lst and serial_ttt_50Mz.lst

    docs directory (documents)
        esx28descv03.htm
        esx28faqv03.htm       

    linux directory (linux build scripts and executable files)
        build
        buildm
        esx28v2
        mult8x8
	testfull
	testpre
        version.txt

    source directory (ESX-28 source code)
        main.cpp
        mult8x8.cpp
        pdl_rdr.cpp
        pdl_rdr.h
        sxcore.cpp
        sxcore.h
        pdlgen\pdl_code.h
        pdlgen\pdl_inc1.h
        pdlgen\pdl_inc2.h
        pdlgen\sx28pdlv3.h

    preview_NB
	NetBurner preview files; see readmeNB.txt.

    vc  directory (Workspace and Projects for Microsoft VC 6)
        To use this copy the source directory into this directory and
        start the esx_release.dsw workspace.  Note that the lib must be
        built before mult8x8.exe is built.  Also note that the esx28v3.exe
        is built with the multi-threaded option.

    WinQuick directory (ESX-28 quick demo)
        diagpre.lst
        esx28v3.exe
        serial_ttt.lst
        serial_ttt_50Mz.lst
        mult8x8.exe
        mult8x8.lst
        readmewq.txt

3)  Build instructions

    Windows:

        esx28v2.exe is built with main.cpp, pdl_rdr.cpp and sxcore.cpp, plus
        the associated header files.

        esx28lib.lib is a static library built with sxcore.cpp plus the associated
        header files.

        mult8x8.exe is built with mutl8x8.cpp, pdl_rdr.cpp, esx28lib.lib, plus
        the associated header files.

        The author uses MS VC6 to build the enclosed binary files.

    Linux:  See the build and buildm scripts in the linux directory.

    Macintosh:  The following instructions kindly supplied by D Myers:

        With the xcode developer tools installed (the open source gcc compiler & complete
        IDE on top of it included free with every Macintosh)

        I followed the linux "build" text file you included in the .zip.

        In the Console "cd" into the "source" directory and type:

        gcc -c pdl_rdr.cpp
        gcc -c sxcore.cpp
        gcc -c main.cpp
        gcc -lm -lstdc++ -o esx28v3 main.o sxcore.o pdl_rdr.o

        done!

/* end of readme.txt */