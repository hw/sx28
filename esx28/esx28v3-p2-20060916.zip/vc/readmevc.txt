09/12/2006 note:

Before trying to build with VC, copy the contents of the "source" folder
to this folder.