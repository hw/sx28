/* sxcore.cpp */

/*
-- Fixes post V2.0
Date 01/04/2006:
1)  Fix to setmem
2)  Addition of serial I/O support (new call back)
Date 02/28/2006:
3)  Change pow() calls to shifts!
Date 03/07/2006:
4)  Opcode display support added
Date 04/25/2006:
5)  Changes for better porting:
	-  type cast of function ptr
    -  SX program in short array (not int)
    -  limit array to 2048
6)	Added mode to show_pgm
-- Fixes post V3.0
Date 09/03/2006:
1)  Fix not resetting PA2 .. PA0 in interrupt handling
2)  Fix to RETIW: restored W value was being used, a corrupted value
3)  Fix to serial_io: added cycles used to call, change way cycles handled internally
Date 09/16/2006:
1)  Set patch level to 2.
*/

/* copyright.txt

ESX28 is copyright 2005-2006 Bob Senser

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the 
"Software"), to deal in the Software without restrictions, including
without limitation the rights to use, copy, modify, publish,
sublicense, and/or sell copies of the Software, and to permit persons
to whom the Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be 
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL BOB SENSER BE LIABLE FOR ANY CLAIM, DAMAGES, OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE
ARISING FROM, OUT OF OR IN CONNECTION WITH THIS THE SOFTWARE OR THE
USE OR OTHER DEALINGS OF THE SOFTWARE.

*/ 

// author notes:
//
// (1) A 2.2GHz PC was showing 4 MIPS, this might be a performance
//     estimate
// (2) The heavy use of macros is need to integrate the generated
//     code modules
// (3) the structure passed in contains the address of the 
//     call-back functions for I/O processing
// (4) the interrupt handling for rb is not supported
// (5) the SLEEP instruction is implimented like a pause/stop
// (6) the CARRYX is the only DEVICE directive used 
//

#define MAJOR_LEVEL 3
#define PATCH_LEVEL 2

#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>

// function headers for contained local functions
void setmem(int, unsigned int);
int getmemflat(int);
int getmem(int);
int shared_sub(int);
int shared_add(int);

void setR_bymode_RA(int);
void setR_bymode_RB(int);
void setR_bymode_RC(int);

#include "sxcore.h"

// files in pdlgen where generated....
#include "pdlgen/sx28pdlv2.h"

#include "pdlgen/pdl_inc1.h"

#include "pdlgen/pdl_inc2.h"

#include "pdl_rdr.h"

//
// SHARED MACROS: instruction macros

#define SET_Z_FROM_W \
	if (getR_WREG() == 0) { \
		setR_Z(1); \
	} else { \
		setR_Z(0); \
	} 

#define SET_Z_FROM_FR(aa) \
	if (getmem(aa) == 0) { \
		setR_Z(1); \
	} else { \
		setR_Z(0); \
	} 
//
// kludge macro - used to handle PAGE inst as skipped inst.
#define KLUDGE if ((run_base.next_instruction & 0xff8) == 0x010) {\
	incR_PC(); }

//
// GROUP 1 MACROS: the Logic Instructions as macros....

#define PDLM_ANDFRW setmem(a1, getR_WREG() & getmem(a1));\
	SET_Z_FROM_FR(a1)

#define PDLM_ANDWFR setR_WREG(getR_WREG() & getmem(a1)); \
	SET_Z_FROM_W

#define PDLM_ANDWLIT setR_WREG(getR_WREG() & a1); \
	SET_Z_FROM_W

#define PDLM_NOTFR setmem(a1, ~getmem(a1));\
	SET_Z_FROM_FR(a1)

#define PDLM_ORFRW setmem(a1, getR_WREG() | getmem(a1));\
	SET_Z_FROM_FR(a1)

#define PDLM_ORWFR setR_WREG(getR_WREG() | getmem(a1)); \
	SET_Z_FROM_W

#define PDLM_ORWLIT setR_WREG(getR_WREG() | a1); \
	SET_Z_FROM_W

#define PDLM_XORFRW setmem(a1, getR_WREG() ^ getmem(a1));\
	SET_Z_FROM_FR(a1)

#define PDLM_XORWFR setR_WREG(getR_WREG() ^ getmem(a1)); \
	SET_Z_FROM_W

#define PDLM_XORWLIT setR_WREG(getR_WREG() ^ a1); \
	SET_Z_FROM_W

//
// GROUP 2 MACROS: the arithmetic and shift instructions as macros 

#define PDLM_ADDFRW\
	setmem(a1, shared_add(a1));\
	SET_Z_FROM_FR(a1)


#define PDLM_ADDWFR\
	setR_WREG(shared_add(a1));\
	SET_Z_FROM_W


#define PDLM_CLRFR setmem(a1,0); setR_Z(1);

#define PDLM_CLRW setR_WREG(0); setR_Z(1);

#define PDLM_CLRWDT setR_TO(1); setR_PD(1);

#define PDLM_DECFR setmem(a1, getmem(a1) - 1); SET_Z_FROM_FR(a1)

#define PDLM_DECSZFR setmem(a1, getmem(a1) - 1);\
		if (getmem(a1) == 0) {KLUDGE incR_PC(); run_base.use_cycle1 = false; }

#define PDLM_INCFR setmem(a1, getmem(a1) + 1); SET_Z_FROM_FR(a1)

#define PDLM_INCSZFR setmem(a1, getmem(a1) + 1);\
		if (getmem(a1) == 0) { KLUDGE incR_PC(); run_base.use_cycle1 = false; }

#define PDLM_SUBFRW\
	setmem(a1, shared_sub(a1));\
	SET_Z_FROM_FR(a1)

#define PDLM_SWAPFR\
	 setmem(a1, ((getmem(a1) & 0x0f) << 4 | (getmem(a1) & 0xf0) >> 4 ) );

//
// GROUP 3 MACROS: bitwise operation instruction macros

#define PDLM_CLRBFRBIT \
	setmem(a2, getmem(a2) & ~((1 << a1)) );
	// setmem(a2, getmem(a2) & ~((int) pow(2,a1)) );

#define PDLM_SETBFRBIT \
	setmem(a2, getmem(a2) | (1 << a1) );
	// setmem(a2, getmem(a2) | ((int) pow(2,a1)) );

#define PDLM_SBFRBIT  run_base.use_cycle1 = false;\
	if (getmem(a2) & (1 << a1) ) \
		 { KLUDGE incR_PC(); run_base.use_cycle1 = false; }
	// if (getmem(a2) & ((int) pow(2,a1)))

#define PDLM_SNBFRBIT run_base.use_cycle1 = false;\
	if (!(getmem(a2) & (1 << a1)) ) \
		 {  KLUDGE incR_PC(); run_base.use_cycle1 = false; }
	// if (!(getmem(a2) & ((int) pow(2,a1)))) 

// GROUP 4 MACROS: the data movement instructions

#define PDLM_MOVWFR		setR_WREG(getmem(a1));	SET_Z_FROM_W

#define PDLM_MOVWFRMW	setR_WREG(shared_sub(a1)); SET_Z_FROM_W

#define PDLM_MOVWLIT	setR_WREG(a1);

#define PDLM_MOVWCFR	setR_WREG(~getmem(a1));	SET_Z_FROM_W

#define PDLM_MOVWMMFR	setR_WREG(getmem(a1) - 1); SET_Z_FROM_W

#define PDLM_MOVWPPFR	setR_WREG(getmem(a1) + 1); SET_Z_FROM_W

#define PDLM_MOVWSWFR\
	 setR_WREG(((getmem(a1) & 0x0f) << 4 | (getmem(a1) & 0xf0) >> 4 ) );

#define PDLM_MOVWM		setR_WREG(getR_MREG());

#define PDLM_MOVSZWMMFR	setR_WREG(getmem(a1) - 1);\
		if (getR_WREG() == 0) {KLUDGE incR_PC(); run_base.use_cycle1 = false;}

#define PDLM_MOVSZWPPFR setR_WREG(getmem(a1) + 1);\
		if (getR_WREG() == 0) {KLUDGE incR_PC(); run_base.use_cycle1 = false;}

#define PDLM_MOVMW		setR_MREG(getR_WREG());

#define PDLM_MOVMLIT	setR_MREG(a1);

#define PDLM_MOVERAW	setR_bymode_RA(getR_WREG());		

#define PDLM_MOVERBW	setR_bymode_RB(getR_WREG());

#define PDLM_MOVERCW	setR_bymode_RC(getR_WREG());
	
#define PDLM_MOVEOPTIONW	setR_OPTION(getR_WREG());

#define PDLM_TESTFR		SET_Z_FROM_FR(a1)

//
// GROUP 5 MACROS: the program control instructions

// interrupt status macros
#define PDLM_SAVE_INT \
	int_base.PC = getR_PC(); \
	int_base.FSR = getR_FSR(); \
	int_base.STATUS = getR_STATUS(); \
	int_base.W = getR_WREG();

#define PDLM_RESTORE_INT \
	{ int TO_hold, PD_hold; \
	setR_PC(int_base.PC); \
	setR_FSR(int_base.FSR); \
	TO_hold = getR_TO(); \
	PD_hold = getR_PD(); \
	setR_STATUS(int_base.STATUS); \
	setR_TO(TO_hold); \
	setR_PD(PD_hold); \
	setR_WREG(int_base.W); }
	

//
// GROUP 6 MACROS: the system control instructions

#define PDLM_BANKADDR8\
	setR_FSR( ((a1 << 5) & 0xe0) | (getR_FSR() & 0x1f) );

#define PDLM_PAGEADDR12\
	setR_PA2(( a1 & 0x4) ? 1 : 0 );\
	setR_PA1(( a1 & 0x2) ? 1 : 0 );\
	setR_PA0(( a1 & 0x1) ? 1 : 0 );

//
// I/O TRIGGER MACROS:

#define PDLM_TRIGGER_READ_RA\
	if (!(run_base.disable_IO) && (run_base.sxcore_cxt -> ra_read != NULL))\
		base.RA = (run_base.sxcore_cxt -> ra_read) (base.TRIS_RA, base.RA,\
			run_base.sxcore_cxt -> tramp);
#define PDLM_TRIGGER_WRITE_RA\
	if (!(run_base.disable_IO) && (run_base.sxcore_cxt -> ra_write!= NULL))\
		(run_base.sxcore_cxt -> ra_write) (base.TRIS_RA, base.RA,\
			run_base.sxcore_cxt -> tramp);


#define PDLM_TRIGGER_READ_RB\
	if (!(run_base.disable_IO) && (run_base.sxcore_cxt -> rb_read!= NULL))\
		base.RB = (run_base.sxcore_cxt -> rb_read) (base.TRIS_RB, base.RB,\
			run_base.sxcore_cxt -> tramp);

#define PDLM_TRIGGER_WRITE_RB\
	if (!(run_base.disable_IO) && (run_base.sxcore_cxt -> rb_write!= NULL))\
		(run_base.sxcore_cxt -> rb_write) (base.TRIS_RB, base.RB,\
			run_base.sxcore_cxt -> tramp);

#define PDLM_TRIGGER_READ_RC\
	if (!(run_base.disable_IO) && (run_base.sxcore_cxt -> rc_read!= NULL) )\
		base.RC = (run_base.sxcore_cxt -> rc_read) (base.TRIS_RC, base.RC,\
			run_base.sxcore_cxt -> tramp);

#define PDLM_TRIGGER_WRITE_RC\
	if (!(run_base.disable_IO) && (run_base.sxcore_cxt -> rc_write!= NULL) )\
		(run_base.sxcore_cxt -> rc_write) (base.TRIS_RB, base.RC,\
			run_base.sxcore_cxt -> tramp);


// constants

const int reg_mem_size = 8;		// SX registers stored in memory
const int actual_mem_size = datamemory + reg_mem_size;
const int max_stack_depth = 8;
const int start = 0x07ff;

// local struct, interrupt context
struct int_cxt {
	int PC;
	int FSR;
	int STATUS;
	int W;
};
static struct int_cxt int_base;

// defined in pdl_inc2.h
static struct cxt base;

// local struct, run context
struct run_cxt {
	unsigned char RTCC_prev;
	int rtcc_calc_cycles;
	int cycles_used;
	int	int_enable;
	// defined in sxcore.h
	struct core_cxt *sxcore_cxt;
	bool disable_IO;
	bool use_cycle1;
	bool last_rtcc_pin_value;
	int	next_instruction;
};
static struct run_cxt run_base;

static unsigned int mem[actual_mem_size];
static int stack[max_stack_depth];
static int stack_index;

// needs to be placed here.....
#include "pdlgen/pdl_code.h"

void push_stack(int a1) {
	if (stack_index >= max_stack_depth) {
		run_base.sxcore_cxt -> core_exit_status |= CORE_EXIT_STACK_OVERFLOW;
		return;
	}
	stack[stack_index] = a1;
	stack_index++;
}

int pop_stack() {
	stack_index--;
	if (stack_index < 0) {
		run_base.sxcore_cxt -> core_exit_status |= CORE_EXIT_STACK_UNDERFLOW;
		return -1;
	}
	return stack[stack_index];
}

void setmem(int addr, unsigned int value) {

	// FIX V2.1 - fix setmem of RA/RB/RC with addition of getmem...
	int local_addr;
	int tris_value;

	// calc sx28 ram address
	if (addr > 0x0f) {
		addr =	(((getR_FSR() & 0xe0 ) >> 1) |
				(addr & 0x0f)) + 0x10;
	}

	if (addr >= (actual_mem_size)) {
		run_base.sxcore_cxt -> core_exit_status |= CORE_EXIT_BAD_FILE_ADDRESS;
		return;
	}

	value &= 0xff;	// need after things like not, etc.

	// note some registers mapped to fsr.....
	switch (addr) {
		case (0x0):
			if (getR_FSR() & 0x10) {
				local_addr = (((getR_FSR() & 0xe0 ) >> 1) |
					(getR_FSR() & 0x0f)) + 0x10;
			} else {
				local_addr = getR_FSR();
			}

			mem[local_addr] = value; 

			break;
		case (0x1):
			if (getR_RTW() == 1) { 
				setR_RTCC(value);
			} else {
				setR_WREG(value);
			}
			break;
		case (0x2):
			setR_PC(value);
			break;
		case (0x3):
			setR_STATUS(value);
			break;
		case (0x4):
			setR_FSR(value);
			break;
		case (0x5):
			tris_value = getR_TRIS_RA();
			setR_RA((value & (~tris_value)) | (getmem(addr) & tris_value));
			break;
		case (0x6):
			tris_value = getR_TRIS_RB();
			setR_RB((value & (~tris_value)) | (getmem(addr) & tris_value));
			break;
		case (0x7):
			tris_value = getR_TRIS_RC();
			setR_RC((value & (~tris_value)) | (getmem(addr) & tris_value));
			break;
		default:
			mem[addr] = value; 
			break;
	}
}

int getmemflat(int addr) {

	int ret;
	int local_addr;

	// note some registers mapped to fsr.....
	switch (addr) {
		case (0x0):
			if (getR_FSR() & 0x10) {
				local_addr = (((getR_FSR() & 0xe0 ) >> 1) |
					(getR_FSR() & 0x0f)) + 0x10;
			} else {
				local_addr = getR_FSR();
			}
			ret = mem[local_addr]; 

			break;
		case (0x1):
			if (getR_RTW() == 1) { 
				ret = getR_RTCC();
			} else {
				ret = getR_WREG();
			}
			break;
		case (0x2):
			ret = getR_PC();
			break;
		case (0x3):
			ret = getR_STATUS();
			break;
		case (0x4):
			ret = getR_FSR();
			break;
		case (0x5):
			ret = getR_RA();
			break;
		case (0x6):
			ret = getR_RB();
			break;
		case (0x7):
			ret = getR_RC();
			break;
		default:
			ret = mem[addr];
			break;
	}

	return ret;
}

int getmem(int addr) {

	int ret;

	// calc sx28 ram address
	if (addr > 0x0f) {
		addr =	(((getR_FSR() & 0xe0 ) >> 1) |
				(addr & 0x0f)) + 0x10;
	}


	if (addr >= (actual_mem_size)) {
		run_base.sxcore_cxt -> core_exit_status |= CORE_EXIT_BAD_FILE_ADDRESS;
		return -1;
	}

	ret = getmemflat(addr);


	return ret;
}

//
// shared subtraction routine
int shared_sub(int a1) {
	// has CARRYX support added!!!!!!!!!!!!

	int mem = getmem(a1);
	int z = getR_WREG();

	if (run_base.sxcore_cxt -> carryx_mode && (getR_C() == 0)) {
		mem--;
	}

	if (mem < z ) { 
		setR_C(0); 
	} else { 
		setR_C(1); 
	} 

	if ((mem & 0x0f) < (z & 0x0f) ) { 
		setR_DC(0); 
	} else { 
		setR_DC(1); 
	} 

	return mem - z;

}

//
// shared addition routine
int shared_add(int a1) {
	// has CARRYX support added!!!!!!!!!!!!

	int mem = getmem(a1);
	int z = getR_WREG();
	int r = mem + z;

	if (run_base.sxcore_cxt -> carryx_mode && getR_C()) {
		r++;
	}

	if (r <= 0xff ) { 
		setR_C(0); 
	} else { 
		setR_C(1); 
	} 

	if (((mem & 0x0f) + (z & 0x0f)) <= 0x0f ) { 
		setR_DC(0); 
	} else { 
		setR_DC(1); 
	} 

	return r;

}

//
// actual instruction code for instruction fully written in here

//
// GROUP 2 INSTRUCTIONS: the arithmetic and shift instructions

void rlfr( int a1) {

	unsigned char c_hold;
	unsigned char mem_hold;

	// Maintenance: 07/14/05
	incR_PC();

	c_hold = getR_C();
	mem_hold = getmem(a1);

	(mem_hold & 0x80) ?  setR_C(1) : setR_C(0);
	setmem(a1, ((mem_hold << 1) | (c_hold & 0x01)) ); 

}

void rrfr( int a1) {

	unsigned char c_hold;
	unsigned char mem_hold;

	// Maintenance: 07/14/05
	incR_PC();
	
	c_hold = getR_C();
	mem_hold = getmem(a1);

	(mem_hold & 0x01) ?  setR_C(1) : setR_C(0);
	setmem(a1, ((mem_hold >> 1) | (c_hold & 0x01) << 7) ); 

}

//
// GROUP 4 INSTRUCTIONS:

void movfrw(int a1) {

	// note: with this instruction, the PC must be updated before the mov!!
	incR_PC();
	setmem(a1, getR_WREG());

}

void movwllfr(int a1) {

	unsigned char c_hold;
	unsigned char mem_hold;

	incR_PC();
	
	c_hold = getR_C();
	mem_hold = getmem(a1);

	(mem_hold & 0x80) ?  setR_C(1) : setR_C(0);
	setR_WREG(((mem_hold << 1) | (c_hold & 0x01)) ); 

}

void movwlrfr(int a1) {

	unsigned char c_hold;
	unsigned char mem_hold;
	
	incR_PC();

	c_hold = getR_C();
	mem_hold = getmem(a1);

	(mem_hold & 0x01) ?  setR_C(1) : setR_C(0);
	setR_WREG(((mem_hold >> 1) | (c_hold & 0x01) << 7) ); 

}

//
// GROUP 5 INSTRUCTIONS:

void calladdr8(int a1) {
	push_stack(getR_PC() + 1);
	setR_PC((a1 & 0xff) + (getR_PA0() << 9) + (getR_PA1() << 10));
}

void jmpaddr9( int a1) {

	int newPC = a1 & 0x1ff;
	
	newPC += (((getR_STATUS() & 0xe0)) << 4);

	setR_PC(newPC);
}

void ret() {
	// setR_PC(pop_stack() + (getR_PA0() << 9) + (getR_PA1() << 10));
	setR_PC(pop_stack());

}

void retp() {
	int	full_addr;
	full_addr = pop_stack();
	setR_PA0(full_addr & 0x200);	// bit 9
	setR_PA1(full_addr & 0x400); // bit 10
	setR_PC(full_addr);
}

void reti() {

	PDLM_RESTORE_INT
	run_base.int_enable = 1;
}

void retiw() {

	setR_RTCC(getR_RTCC() + getR_WREG()); 

	PDLM_RESTORE_INT		// FIX, restore moved from above 09/03/2006
	run_base.int_enable = 1;
}

void retwlit(int a1) {
	setR_WREG(a1);
	setR_PC(pop_stack());
}


//
// GROUP 6 INSTRUCTIONS:

void iread () {

	int address;
	int value;

	incR_PC();

	address = ((getR_MREG() & 0x0f) << 8) + getR_WREG();
	if (address > pgm_mem_size) {
		run_base.sxcore_cxt -> core_exit_status |= CORE_EXIT_BAD_PGM_ADDRESS;
		return;
	}
	value = run_base.sxcore_cxt -> pgm_mem[address];
	setR_WREG(value & 0xff);
	setR_MREG((value & 0xf00) >> 8);

}

void sleep() {

	incR_PC();

	setR_TO(1);
	setR_PD(0);

	run_base.sxcore_cxt -> core_exit_status |= CORE_EXIT_SLEEP;
}


// TRIS, etc handling by mode setting

void setR_bymode_RA(int a1) {

	switch (getR_MREG()) {
	case (0x0f):
		setR_TRIS_RA(a1);
		break;
	case (0x0e):
		setR_PLP_RA(a1);
		break;
	case (0x0d):
		setR_LVL_RA(a1);
		break;
	}
}
void setR_bymode_RB(int a1) {

	switch (getR_MREG()) {
	case (0x0f):
		setR_TRIS_RB(a1);
		break;
	case (0x0e):
		setR_PLP_RB(a1);
		break;
	case (0x0d):
		setR_LVL_RB(a1);
		break;
	case (0x0c):
		setR_ST_RB(a1);
		break;
	case (0x0b):
		setR_WKEN_RB(a1);
		break;
	case (0x0a):
		setR_WKED_RB(a1);
		break;
	case (0x09):
		// this is a swap...
		setR_WREG(getR_WKPND_RB());
		setR_WKPND_RB(a1);
		break;
	case (0x08):
		// this is a swap...
		setR_WREG(getR_CMP_RB());
		setR_CMP_RB(a1);
		break;
	}

}
void setR_bymode_RC(int a1) {
	switch (getR_MREG()) {
	case (0x0f):
		setR_TRIS_RC(a1);
		break;
	case (0x0e):
		setR_PLP_RC(a1);
		break;
	case (0x0d):
		setR_LVL_RC(a1);
		break;
	case (0x0c):
		setR_ST_RC(a1);
		break;
	}

}

// OTHER FUNCTIONS, some using printf....

void dump_regs(char * tag) {
	char break_string[32];
	sprintf(break_string,"%04x", run_base.sxcore_cxt -> break_addr);
	printf("PC: %04x, W: %02x "
		"PA2: %x PA1: %x PA0 %x TO: %x "
		"PD: %x Z: %x DC: %x C: %x "
		"M: %02x, BR: %s\n",
		getR_PC(),
		getR_WREG(),
		getR_PA2(),
		getR_PA1(),
		getR_PA0(),
		getR_TO(),
		getR_PD(),
		getR_Z(),
		getR_DC(),
		getR_C(),
		getR_MREG(),
		(run_base.sxcore_cxt -> break_addr < 0) ? "-" : break_string);
}

void dump_ioregs() {

	// this "disable" approach is a kludge, but it works....
	bool disable_hold;

	disable_hold = run_base.disable_IO;
	run_base.disable_IO = true;

	printf("TRIS and other I/O registers:\n");
	printf("RA: %02x, TRIS: %02x PLP: %02x LVL: %02x\n", 
		getR_RA(), getR_TRIS_RA(), getR_PLP_RA(), getR_LVL_RA());
	printf("RB: %02x, TRIS: %02x PLP: %02x LVL: %02x ST: %02x "
		   "WKEN: %02x WKED: %02x WKPND: %02x CMP: %02x\n", 
		getR_RB(), getR_TRIS_RB(), getR_PLP_RB(), getR_LVL_RB(), getR_ST_RB(),
		getR_WKEN_RB(), getR_WKED_RB(), getR_WKPND_RB(), getR_CMP_RB());
	printf("RC: %02x, TRIS: %02x PLP: %02x LVL: %02x ST: %02x\n", 
		getR_RC(), getR_TRIS_RC(), getR_PLP_RC(), getR_LVL_RC(), getR_ST_RC());

	printf("\n");

	run_base.disable_IO = disable_hold;
}

void show_mem() {

	int i;
	unsigned char c;

	// this "disable" approach is a kludge, but it works....
	bool disable_hold;

	disable_hold = run_base.disable_IO;
	run_base.disable_IO = true;

	printf("Memory: (0x%x bytes)\n", actual_mem_size);
	
	for (i=0;i < actual_mem_size; i++) {
		if (i == 0) printf("%04x ", i);
		if ((i % 16) == 0 && i != 0) printf("\n%04x ",
			 (i < 0x20)? i : (i * 2) - 0x10);
		c = (unsigned char) getmemflat(i);
		printf(" %02x", c);
		if (((i + 1) % 16) != 0 && ((i + 1) % 8) == 0) printf(" -");
	}
	printf("\n");

	run_base.disable_IO = disable_hold;
}

void show_pgm(struct core_cxt *show_cxt, char mode) {

	// if mode is 'd', dump format
	// if mode is 'c', c-code format

	int i;

	printf("esx Program Memory: (0x%x bytes)\n", pgm_mem_size);
	
	for (i=0;i < pgm_mem_size; i++) {
		if (mode == 'd') {
			if (i == 0) printf("%04x ", i);
			if ((i % 8) == 0 && i != 0) printf("\n%04x ",i);
			printf(" %03x", show_cxt -> pgm_mem[i]);
		} else {
			if ((i % 8) == 0 && i != 0) printf("\n");
			printf(" 0x%03x,", show_cxt -> pgm_mem[i]);
		}
	}
	printf("\n");

}

// end of functions allowed to use printf...


void update_RTCC( int call_mode, int used ) {

	int psx_factor;
	bool new_rtcc_pin_value;

	if (getR_RTS() == 0) { // done by internal clock
		run_base.rtcc_calc_cycles += used;
	} else {	// done by external rtcc pin
		if (run_base.sxcore_cxt -> rtcc_read != NULL) {
		new_rtcc_pin_value = run_base.sxcore_cxt ->
			rtcc_read (run_base.last_rtcc_pin_value, call_mode, run_base.sxcore_cxt ->tramp);
		if (getR_RTE() == 0 && 
			(run_base.last_rtcc_pin_value < new_rtcc_pin_value)) {
			run_base.rtcc_calc_cycles += 1;
		} else if (getR_RTE() == 1 &&
			(run_base.last_rtcc_pin_value > new_rtcc_pin_value)) {
			run_base.rtcc_calc_cycles += 1;
		}
		run_base.last_rtcc_pin_value = new_rtcc_pin_value;
		}
	}

	if (getR_PSA() == 1) {	// RTCC divide rate is 1:1
		// printf("DEBUG 1:1\n");
		run_base.RTCC_prev = getR_RTCC();
		setR_RTCC(getR_RTCC() + run_base.rtcc_calc_cycles);
		run_base.rtcc_calc_cycles = 0;
	} else {			// RTCC divide rate determined by PSx
		// printf("DEBUG 1:n\n");
		// psx_factor = (int) pow(2.0, ((double) ((getR_OPTION() & 0x07)) + 1.0) );
		psx_factor = 1 << ( (getR_OPTION() & 0x07) + 1);
		run_base.RTCC_prev = getR_RTCC();
		setR_RTCC(getR_RTCC() + (run_base.rtcc_calc_cycles / psx_factor));
		run_base.rtcc_calc_cycles = run_base.rtcc_calc_cycles % psx_factor;
	}

}

unsigned char *get_opcode_text(unsigned int opcode) {

	unsigned char* return_value = NULL;

	int i = 0;
	int shift_value;
	unsigned int opcode_from_instructions;
	unsigned int opcode_from_pgm;

	while (instructions[i].ptr != NULL) {
		shift_value = 12 - (instructions[i].ptr -> op_bits);
		opcode_from_instructions = instructions[i].opcode >> shift_value;
		opcode_from_pgm = opcode >> shift_value;
		if (opcode_from_instructions == opcode_from_pgm) {
			return_value = instructions[i].opcode_text;
			break;
		}
		i++;
	}

	return return_value;

}

//
// SX_INIT
//
void sx_init(struct core_cxt *calling_cxt) {

	run_base.sxcore_cxt = calling_cxt;

	calling_cxt -> major_version = MAJOR_LEVEL;
	calling_cxt -> patch_level = PATCH_LEVEL;
	calling_cxt -> pdl_cut = PDL_INC1;

	setR_IND(0);
	setR_RTCC(0);
	setR_WREG(0);
	setR_PC(0);
	setR_STATUS(0);
	setR_TO(1);		// part of STATUS....
	setR_PD(1);		// part of STATUS....
	setR_IND(2);
	setR_FSR(0);
	run_base.disable_IO = true;
	// RA init
	setR_RA(0);
	setR_TRIS_RA(0x0f);
	setR_LVL_RA(0x0f);
	setR_PLP_RA(0x0f);
	// RB init
	setR_RB(0);
	setR_TRIS_RB(0xff);
	setR_LVL_RB(0xff);
	setR_PLP_RB(0xff);
	setR_ST_RB(0xff);
	setR_WKEN_RB(0xff);
	setR_WKED_RB(0xff);
	setR_WKPND_RB(0xff);
	setR_CMP_RB(0xff);
	// RC init
	setR_RC(0);
	setR_TRIS_RC(0xff);
	setR_LVL_RC(0xff);
	setR_PLP_RC(0xff);
	setR_ST_RC(0xff);
	//
	run_base.disable_IO = false;
	setR_MREG(0x0f);
	setR_OPTION(0xff);  

	stack_index = 0;
	run_base.rtcc_calc_cycles = 0;
	run_base.RTCC_prev = 0;
	run_base.int_enable = 1;
	run_base.last_rtcc_pin_value = 1;

	base.PC = start;	// this is an SX code addr

	return;

}

//
// SX_CORE
//
int sx_core (int run_mode, struct core_cxt *calling_cxt ) {

	struct pdl_inst *inst_ptr;
	struct pdl_temp *temp_ptr;
	// unsigned int *ptr;
	unsigned short *ptr;	// due to int to short change
	bool processed;
	int i;
	int opcode_size;
	int opcode_from_instructions;
	int opcode_from_pgm;
	int inst_from_instructions;
	int inst_from_pgm;
	int shift_value;
	int arg1;
	int arg2;
	int argw;
	int partial;

	run_base.sxcore_cxt = calling_cxt;
	run_base.sxcore_cxt -> core_exit_status = 0;
	int cycles_used = 0;
	int call_cycles_used = 0;

	while (1) {

		cycles_used = 0;

		// check for RTCC interrupt
		if (getR_RTI() == 0 &&
			run_base.int_enable == 1 &&
			getR_RTCC() < run_base.RTCC_prev) {
			update_RTCC(UPDATE_RTCC_INTERRUPT, 3);	// cycles / interrupt
			cycles_used += 3;
			run_base.int_enable = 0;
			PDLM_SAVE_INT
			setR_PC(0);
			setR_PA2(0);        // FIX post V3.0 09/03/2006
			setR_PA1(0);        // likely better to use mask, but....
			setR_PA0(0);
		
			run_base.sxcore_cxt -> core_exit_status |= CORE_EXIT_INTERRUPT;
		}

		ptr = run_base.sxcore_cxt -> pgm_mem;   // pgm;
		ptr += base.PC;
		processed = false;

		run_base.use_cycle1 = true;	// assume normal clock cycles / instruction

		// dispatch instruction....
		// ... not optimized ...
		for (i=0; i < 255; i++) {
			inst_ptr = &instructions[i];
			temp_ptr = inst_ptr -> ptr;
			if (temp_ptr == NULL) {
				return RUN_FAIL_UNKNOWN_INSTRUCTION;
			}

			// scan table for this opcode, use the length bits
			// when match, find routine name and then call

			inst_from_instructions = inst_ptr -> opcode;
			inst_from_pgm = *ptr;
			opcode_size = temp_ptr -> op_bits;
			shift_value = 12 - opcode_size;

			// kludge, added later for odd-ball instructions....
			run_base.next_instruction = *(ptr + 1);

			opcode_from_instructions = inst_from_instructions >> shift_value;
			opcode_from_pgm = inst_from_pgm >> shift_value;

			if (opcode_from_instructions == opcode_from_pgm) {
				processed = true;

				if ((temp_ptr -> a1_bits) == 0 &&
					(temp_ptr -> a2_bits) == 0) {
				/* opcode is full instruction */
					 ((void (*) ()) inst_ptr -> c_code_ptr)();
				} else if (temp_ptr -> a2_bits == 0) {
				/* there is one operand */ 
					argw = (inst_from_pgm >> temp_ptr -> a1_bits) << temp_ptr -> a1_bits;
					arg1 = inst_from_pgm - argw;
					((void (*) (int )) inst_ptr -> c_code_ptr)(arg1);
				} else {
				/* there are two operands */
					partial = inst_from_pgm >> temp_ptr -> a2_bits;
					argw = (partial >> temp_ptr -> a1_bits) << temp_ptr -> a1_bits;
					arg1 = partial - argw;
					argw = (inst_from_pgm >> temp_ptr -> a2_bits) << temp_ptr -> a2_bits;
					arg2 = inst_from_pgm - argw;
					((void (*) (int, int)) inst_ptr -> c_code_ptr)(arg1, arg2);
				}
			} // if ....

			if (processed) {
				break;
			}
		} // for

		// check for stack error
		if ((run_base.sxcore_cxt -> core_exit_status & CORE_EXIT_STACK_OVERFLOW) ||
		    (run_base.sxcore_cxt -> core_exit_status & CORE_EXIT_STACK_UNDERFLOW)) {
			return(RUN_FAIL_STACK_ERROR);
		}

		// check for address error
		if ((run_base.sxcore_cxt -> core_exit_status & CORE_EXIT_BAD_PGM_ADDRESS) ||
		    (run_base.sxcore_cxt -> core_exit_status & CORE_EXIT_BAD_FILE_ADDRESS)) {
			return(RUN_FAIL_ADDRESS_ERROR);
		}

		// now that instruction processed, update total cycles used
		if (run_base.use_cycle1) {
			run_base.cycles_used = inst_ptr -> cycles1;
		} else {
			run_base.cycles_used = inst_ptr -> cycles2;
		}
		cycles_used += run_base.cycles_used;

		// this is a good place to call an external 
		// "virtual time" routine....
		update_RTCC(UPDATE_RTCC_INSTRUCTION, run_base.cycles_used);

		// call serial I/O routine if defined.
		if (run_base.sxcore_cxt -> serial_hook != NULL) {
			run_base.sxcore_cxt ->
			serial_hook (run_base.sxcore_cxt ->tramp, cycles_used);  // FIX 09/03/2006
		}
		call_cycles_used += cycles_used;

		if (run_mode != RUN_MODE_FULL) {
			break;
		}


	} // while

	return call_cycles_used;

}

// end of sxcore.cpp
