//pdl_inc1.h tag: 1073823776
#define PDL_INC1  1073823776
/* copyright.txt

ESX28 is copyright 2005-2006 Bob Senser

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the 
"Software"), to deal in the Software without restrictions, including
without limitation the rights to use, copy, modify, publish,
sublicense, and/or sell copies of the Software, and to permit persons
to whom the Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be 
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL BOB SENSER BE LIABLE FOR ANY CLAIM, DAMAGES, OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE
ARISING FROM, OUT OF OR IN CONNECTION WITH THIS THE SOFTWARE OR THE
USE OR OTHER DEALINGS OF THE SOFTWARE.

*/ 
void andfrw ( int );
void andwfr ( int );
void andwlit ( int );
void notfr ( int );
void orfrw ( int );
void orwfr ( int );
void orwlit ( int );
void xorfrw ( int );
void xorwfr ( int );
void xorwlit ( int );
void addfrw ( int );
void addwfr ( int );
void clrfr ( int );
void clrw ( );
void clrwdt ( );
void decfr ( int );
void decszfr ( int );
void incfr ( int );
void incszfr ( int );
void rlfr ( int );
void rrfr ( int );
void subfrw ( int );
void swapfr ( int );
void clrbfrbit ( int,  int );
void sbfrbit ( int,  int );
void setbfrbit ( int,  int );
void snbfrbit ( int,  int );
void movfrw ( int );
void movwfr ( int );
void movwfrmw ( int );
void movwlit ( int );
void movwcfr ( int );
void movwmmfr ( int );
void movwppfr ( int );
void movwllfr ( int );
void movwlrfr ( int );
void movwswfr ( int );
void movwm ( );
void movszwmmfr ( int );
void movszwppfr ( int );
void movmw ( );
void movmlit ( int );
void moveraw ( );
void moverbw ( );
void movercw ( );
void moveoptionw ( );
void testfr ( int );
void calladdr8 ( int );
void jmpaddr9 ( int );
void nop ( );
void ret ( );
void retp ( );
void reti ( );
void retiw ( );
void retwlit ( int );
void bankaddr8 ( int );
void iread ( );
void pageaddr12 ( int );
void sleep ( );
