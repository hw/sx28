September 16, 2006

This directory contains a version of the Scenix/Ubicom/Parallax Serial Virtual Peripheral (Copyrighted 1999 by Scenix).  This code provides the SX with a serial UART capability and does this via SX interrupts.

This preview shows ESX-28 correctly running SX 28 code with interrupts.  The code layout has been slightly modified to work with the ESX-28 program loader; no changes were made to functionality.  The changes are detailed at the start of the uart_vp_esx.src module.  

This directory should contain these files:

esx28v3.exe
readmeVPUART.txt
uart_vp_esx.lst
uart_vp_esx.src

To run this preview, enter:

c:\>esx28v3 -sx uart_vp_esx.lst

The program will echo back any characters typed and add line-feed to any "enter" keys entered.  Use a "control C" to exit.

/* end of readme */


