//
// pdl_rdr.cpp
//

/* copyright.txt

ESX28 is copyright 2005-2006 Bob Senser

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the 
"Software"), to deal in the Software without restrictions, including
without limitation the rights to use, copy, modify, publish,
sublicense, and/or sell copies of the Software, and to permit persons
to whom the Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be 
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL BOB SENSER BE LIABLE FOR ANY CLAIM, DAMAGES, OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE
ARISING FROM, OUT OF OR IN CONNECTION WITH THIS THE SOFTWARE OR THE
USE OR OTHER DEALINGS OF THE SOFTWARE.

*/ 

//
// Comments from author:
//
// C-style program to read the Parallax Assembler/Compiler (SXB) 
// listing for the generated SX code.
//
// Important:
// This routine is a heuristic "hack" and needs to be rewitten! Known
// limits and workarounds:
// 1)  it DOES detect the DEVICE "carryx" setting and the SX
//     processor type.
// 2)  it DOES NOT correctly handle Device settings conditional
//     assembly code -- for example in Sx_arith.src.  Workaround is
//     to comment out unwanted DEVICE lines.
// 3)  any assembler macros used MUST BE expanded.  Workaround is 
//     to avoid using the "noexpand" and be sure the macro source
//     contains "expand" -- for example in uart_vp.src.
// 4)  it DOES handle multi-line instruction expansions
// 5)  it DOES probably have bugs.....
//

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "pdl_rdr.h"


int lstrdr(char * file_name, int array_size, unsigned short array[] ) {

	int i;
	unsigned int ui;
	char * ptr;
	char * ptr1;
	char * ptr2;
	char * ptr3;
	char * ptr4;
	unsigned int addr;
	unsigned int value;
	bool ok = true;
	bool has_linenum;
	char  buffer[255];
	char  orig_buffer[255];
	FILE *lst_file;
	int	return_value;

	for (i=0; i < array_size; i++) {

		array[i] = 0xfff;
	}

	lst_file = fopen(file_name, "r");
	if (lst_file == NULL) {
		return -1;
	}

	return_value = 0;

	while(ok) {
		ptr = fgets(buffer, sizeof(buffer)-1, lst_file);
		if (ptr == NULL) {
			ok = false;
		} else {
			strcpy(orig_buffer,ptr);
			// make all upper case for simplicity...
			for (ui=0; ui < strlen(ptr); ui++) {
				ptr[ui] = toupper(ptr[ui]);

			}
			if (strlen(ptr) > 7) {
				if (memcmp(ptr,"CROSS R", 7) == 0) {
					ok = false;
					break;
				}
			}
			if (strlen(ptr) > 3) {
				if (memcmp(ptr, "***", 3) == 0) {
					continue;	// skip warning lines
				}
			}
			// looking for decnum hexnum hexnum or
			//                    hexnum hexnum or
			//					  hexnum hexnum hexnum ....
			// or
			//				decnum hexnum dexnum  device ....
			// ignore comment lines and literals with "=" present
			// note:  comments don't have hexnums (data values)
			has_linenum = true;
			if (strlen(ptr) > 5) {
				if (memcmp(ptr,"      ", 6) == 0) {
					has_linenum = false;
				}
			}

			if (has_linenum) {
				ptr1 = strpbrk(ptr,"1234567890"); //decimal num
				if (ptr1 == NULL) continue;	
				ptr2 = strstr(ptr1," ");
				if (ptr2 == NULL) continue;	
			} else {
				ptr3 = strpbrk(ptr2,"0123456789ABCDEF"); // hex num
				if (ptr3 == NULL) {
					ok = false;
				}
				ptr2 = ptr3;
			} 

			// kludgy way to handle Device (or FUSES or PROCESSOR)
			if (ok && has_linenum) {
				ptr4 = strstr(ptr2," ");	// skip space after line num
				if ((ptr3 = strstr(ptr2,";")) != NULL) {
					*ptr3 = 0;			// kill comment area
				}
// suspect this code is not needed....
#if 0
				if (ptr4 != NULL) {
					ptr4 = strpbrk(ptr4,"0123456789ABCDEF"); // skip to hex num
					if (ptr4 != NULL) {
						ptr4 = strstr(ptr4," ");  // skip to space after hex num
						if (ptr4 != NULL) {
							ptr4 = strpbrk(ptr4,"0123456789ABCDEF"); // skip to hex num
							if (ptr4 != NULL) {
								ptr4 = strstr(ptr4," ");  // skip to space after hex num
							}
						}
					}
				}
#endif
				if (ptr4 != NULL) {
					while (ptr4 != NULL && *ptr4 == ' ') {
						ptr4++;
					}
					// now can look for DEVICE and options...
					if (strstr(ptr4,"DEVICE") != NULL ||
						strstr(ptr4,"FUSE") != NULL ||
						strstr(ptr4, "PROCESSOR") != NULL) {
						if (strstr(ptr4, "CARRYX") != NULL) {
							return_value |= RDR_CARRYX_PRESENT;
						}
						if (strstr(ptr4, "SX28") != NULL ||
							strstr(ptr4, "PINS28") != NULL) {
							return_value |= RDR_SX28_DEFINED;
						}
						continue;	// don't process DEVICE farther...
					}
				}
			}

			// only process generated code values, no assembler text
			if (has_linenum && strlen(buffer) > 22) {
				buffer[22] = 0;
			}

			// printf("DEBUG: %s\n", buffer);

			if (ok) {
				ptr2 = strpbrk(ptr2,";=0123456789ABCDEF"); // hex num plus
				if (ptr2 == NULL) continue;
				if (*ptr2 == ';') continue;		// skip comment
				if (*ptr2 == '=') continue;		// skip literal
				ptr3 = strstr(ptr2," ");
				if (ptr3 == NULL) continue;
				ptr3 = strpbrk(ptr3,"0123456789ABCDEF"); // hex num
				if (ptr3 == NULL) continue;
				sscanf(ptr2,"%x",&addr);
				sscanf(ptr3,"%x",&value);
				// printf("DEBUG %04x %04x\n", addr, value);
				if (addr > 0x7ff) {
					printf("Internal error in rdr (1), addr over 0x7ff!\n");
					printf("line: %s\n", orig_buffer);
					return -1;
				}
				// printf("DEBUG: addr: %x value: %x\n", addr, value);

				array[addr] = value;
				// check for more values
				while (!has_linenum) {
					ptr3 = strpbrk(ptr3," ");
					if (ptr3 == NULL) break;
					ptr3 = strpbrk(ptr3,"0123456789ABCDEF"); // hex num
					if (ptr3 == NULL) break; 
					sscanf(ptr3,"%x",&value);
					addr++;
					if (addr > 0x7ff) {
						printf("Internal error in rdr (2), addr over 0x7ff!\n");
						printf("line: %s\n", orig_buffer);
						return -1;
					}
					array[addr] = value;
				}
			}

			// printf("%s", buffer);
		}

	}

	fclose(lst_file);

	return return_value;

}

// end of pdl_rdr.cpp